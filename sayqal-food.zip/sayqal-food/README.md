# SAYQAL FOOD — Telegram Mini App (hot-dog, lavash, chicken + O'yinlar)

Fayllar: `index.html` (Menyu · Savat · O'yinlar), `mafia.html` (Mafia), `durak.html`, `chess.html` (Shaxmat), `checkers.html` (Shashka), `seabattle.html` (Dengiz jangi), `domino.html` (Domino), `surf.html` (Sayqal Surf), `supabase/` (Mafia serveri), `bot_example.py`.

## Ishga tushirish
1. Barcha `.html` fayllar (`index.html`, `mafia.html`, `durak.html`, `chess.html`, `checkers.html`, `seabattle.html`, `domino.html`, `surf.html`) (va `config.example.js` qismi) ni bitta HTTPS hostingga joylang (Bolt/Netlify/GitHub Pages) — bir papkada.
2. Menyu va narxlar: `index.html` ichida `MENU` ro'yxati (hozirgi narxlar NAMUNA — o'zingiznikiga almashtiring).
3. @BotFather → `/newbot` (yoki mavjud bot) → Bot Settings → Menu Button → URL = hosting manzili (index.html).
4. Buyurtmalar botga kelishi uchun `bot_example.py` dagi `/start` va `web_app_data` qismini mavjud `bot.py` ga qo'shing (hech narsani o'chirmang). Muhit o'zgaruvchilari: `BOT_TOKEN`, `ADMIN_ID`, `APP_URL`.
   Eslatma: `sendData` faqat klaviatura tugmasi orqali ochilgan ilovada ishlaydi (`/start` dagi tugma). Menu Button orqali ochilsa, buyurtma matni nusxalanadi.
5. **Mafia online** (do'stlar/tasodifiy) uchun: Supabase → SQL Editor'da `001`, keyin `002` migratsiyani ishga tushiring; bot tokenni `mafia_config` ga kiriting; `config.example.js` dagi `window.SAYQAL_CONFIG` ni `mafia.html` ichiga qo'shing (`inviteBase` = Mini App havolasi). AI rejimi serversiz ishlaydi.


## O'yin tangalari (stavkalar)
Har bir o'yin sahifasi 2 000 o'yin tangasi bilan boshlanadi (haqiqiy pul emas). Stavkalar: 200 · 300 · 500 · 1 000 · 2 000 · 5 000 · 10 000. Yutuq stavkani ikki baravar qaytaradi, yutqazilsa stavka ketadi, durangda qaytadi. Durak: 2/3/4 o'yinchi ×2/×1.5/×1.33. Surf: ball bo'yicha ×1/×2/×4/×8. Balans telefonda (localStorage) har bir o'yin uchun alohida saqlanadi; tugasa «2 000 tanga olish» tugmasi chiqadi.
