# Namuna bot (pyTelegramBotAPI + Flask webhook, Render uchun).
# MAVJUD bot.py ni O'CHIRMANG: undan faqat /start va web_app_data qismlarini ko'chirib qo'shing.
import os, json, telebot
from telebot import types
from flask import Flask, request

TOKEN = os.environ["BOT_TOKEN"]
ADMIN_ID = int(os.environ["ADMIN_ID"])            # buyurtmalar keladigan chat ID
APP_URL = os.environ["APP_URL"]                   # Mini App HTTPS manzili (index.html joylangan joy)
bot = telebot.TeleBot(TOKEN, threaded=False)
app = Flask(__name__)

@bot.message_handler(commands=["start"])
def start(m):
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    # MUHIM: buyurtma tugmasi aynan KLAVIATURA tugmasi bo'lishi kerak, shunda sendData ishlaydi
    kb.add(types.KeyboardButton("🍔 SAYQAL FOOD — buyurtma", web_app=types.WebAppInfo(APP_URL)))
    bot.send_message(m.chat.id, "SAYQAL FOOD ga xush kelibsiz! Hot-dog, lavash, chicken 🔥\nO'yinlar bo'limida Mafia ham bor 🕵️", reply_markup=kb)

@bot.message_handler(content_types=["web_app_data"])
def order(m):
    try:
        o = json.loads(m.web_app_data.data)
    except Exception:
        return
    if o.get("type") != "order":
        return
    lines = "\n".join(f"• {i['name']} × {i['qty']} = {i['sum']:,}".replace(",", " ") for i in o["items"])
    text = (f"🧾 Yangi buyurtma\n{lines}\nJami: {o['total']:,} so'm\n📞 {o['phone']}\n📍 {o['address']}"
            + (f"\n💬 {o['note']}" if o.get("note") else "")
            + f"\n👤 {m.from_user.first_name} (@{m.from_user.username or '-'}, id {m.from_user.id})").replace(",", " ")
    bot.send_message(ADMIN_ID, text)
    bot.send_message(m.chat.id, "✅ Buyurtmangiz qabul qilindi! Tez orada bog'lanamiz.")

@app.route("/" + TOKEN, methods=["POST"])
def hook():
    bot.process_new_updates([telebot.types.Update.de_json(request.get_data().decode("utf-8"))])
    return "ok"

# Webhook sozlamalarini mavjud bot.py dagidek saqlang (Render URL o'zgarmasin).
