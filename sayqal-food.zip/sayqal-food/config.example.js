// index.html ichida, asosiy <script> dan OLDIN qo'shing (yoki Bolt/hosting'dagi index.html ga qo'ying):
window.SAYQAL_CONFIG = {
  url: "https://XXXX.supabase.co",           // Supabase Project URL
  key: "eyJ...anon-public-key...",            // Supabase anon (public) kalit
  inviteBase: "https://t.me/SIZNING_BOT/app"  // BotFather'dagi Mini App havolasi (taklif tugmasi uchun)
};
