-- SAYQAL FOOD · Mafia: server tomonidan boshqariladigan multiplayer.
-- Qoidalar: mafia / doktor / detektiv / tinch aholi. Mafia soni >= qolganlar bo'lsa mafia yutadi,
-- mafia 0 bo'lsa tinch aholi yutadi. Rollar faqat serverda (mafia_secrets) turadi.
-- DIQQAT: rollar taqsimoti (mafia = n/3, 1 doktor, 1 detektiv) — mavjud o'yindagi sozlamaga moslang.

create extension if not exists pgcrypto;

create table if not exists mafia_rooms (
  code           text primary key,
  host_id        text not null,
  mode           text not null check (mode in ('friends','random','ai')),
  phase          text not null default 'lobby' check (phase in ('lobby','night','day','vote','gameover')),
  day            int  not null default 0,
  phase_ends_at  timestamptz,
  winner         text check (winner in ('mafia','civilians')),
  last_event     jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now()
);

-- OMMAVIY jadval: rol ustuni yo'q. revealed_role faqat o'lgandan keyin / o'yin tugagach to'ldiriladi.
create table if not exists mafia_players (
  room_code     text not null references mafia_rooms(code) on delete cascade,
  player_id     text not null,
  name          text not null,
  seat          int  not null,
  alive         boolean not null default true,
  is_ai         boolean not null default false,
  revealed_role text,
  primary key (room_code, player_id)
);

-- YASHIRIN jadvallar: RLS yoqilgan, hech qanday policy yo'q => anon/authenticated o'qiy olmaydi.
create table if not exists mafia_secrets (
  room_code text not null references mafia_rooms(code) on delete cascade,
  player_id text not null,
  token     uuid not null default gen_random_uuid(),
  role      text,
  primary key (room_code, player_id)
);
create table if not exists mafia_actions (
  room_code text not null references mafia_rooms(code) on delete cascade,
  day       int  not null,
  kind      text not null check (kind in ('kill','save','check','vote')),
  actor     text not null,
  target    text not null,
  primary key (room_code, day, kind, actor)
);
create table if not exists mafia_notes (
  room_code text not null references mafia_rooms(code) on delete cascade,
  player_id text not null,
  day       int  not null,
  note      text not null
);

alter table mafia_rooms   enable row level security;
alter table mafia_players enable row level security;
alter table mafia_secrets enable row level security;
alter table mafia_actions enable row level security;
alter table mafia_notes   enable row level security;

drop policy if exists "mafia rooms read"   on mafia_rooms;
drop policy if exists "mafia players read" on mafia_players;
create policy "mafia rooms read"   on mafia_rooms   for select using (true);
create policy "mafia players read" on mafia_players for select using (true);
-- yozish policy yo'q: barcha o'zgarish faqat quyidagi SECURITY DEFINER funksiyalar orqali.

do $$ begin
  alter publication supabase_realtime add table mafia_rooms;
exception when others then null; end $$;
do $$ begin
  alter publication supabase_realtime add table mafia_players;
exception when others then null; end $$;

-- ---------- yordamchilar ----------
create or replace function _mafia_auth(p_code text, p_pid text, p_token uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from mafia_secrets where room_code = p_code and player_id = p_pid and token = p_token) then
    raise exception 'unauthorized';
  end if;
end $$;

create or replace function _mafia_check_win(p_code text) returns text
language plpgsql security definer set search_path = public as $$
declare m int; c int;
begin
  select count(*) filter (where s.role = 'mafia'), count(*) filter (where s.role <> 'mafia')
    into m, c
    from mafia_players p join mafia_secrets s using (room_code, player_id)
   where p.room_code = p_code and p.alive;
  if m = 0 then return 'civilians'; end if;
  if m >= c then return 'mafia'; end if;
  return null;
end $$;

create or replace function _mafia_kill(p_code text, p_pid text) returns void
language sql security definer set search_path = public as $$
  update mafia_players p set alive = false,
         revealed_role = (select role from mafia_secrets s where s.room_code = p.room_code and s.player_id = p.player_id)
   where p.room_code = p_code and p.player_id = p_pid;
$$;

-- ---------- xonalar ----------
create or replace function mafia_create_room(p_player_id text, p_name text, p_mode text default 'friends')
returns table (code text, token uuid)
language plpgsql security definer set search_path = public as $$
declare c text; t uuid;
begin
  loop
    c := upper(substr(md5(random()::text || clock_timestamp()::text), 1, 5));
    exit when not exists (select 1 from mafia_rooms where mafia_rooms.code = c);
  end loop;
  insert into mafia_rooms(code, host_id, mode) values (c, p_player_id, p_mode);
  insert into mafia_players(room_code, player_id, name, seat) values (c, p_player_id, left(p_name, 24), 0);
  insert into mafia_secrets(room_code, player_id) values (c, p_player_id) returning mafia_secrets.token into t;
  return query select c, t;
end $$;

create or replace function mafia_join_room(p_code text, p_player_id text, p_name text) returns uuid
language plpgsql security definer set search_path = public as $$
declare r mafia_rooms; t uuid; n int;
begin
  select * into r from mafia_rooms where code = upper(p_code) for update;
  if not found or r.phase <> 'lobby' then raise exception 'room_unavailable'; end if;
  select token into t from mafia_secrets where room_code = r.code and player_id = p_player_id;
  if t is not null then return t; end if;               -- qayta ulanish
  select count(*) into n from mafia_players where room_code = r.code;
  if n >= 12 then raise exception 'room_full'; end if;
  insert into mafia_players(room_code, player_id, name, seat) values (r.code, p_player_id, left(p_name, 24), n);
  insert into mafia_secrets(room_code, player_id) values (r.code, p_player_id) returning token into t;
  return t;
end $$;

-- Tasodifiy o'yin: ochiq xonaga qo'shiladi yoki yangisini ochadi
create or replace function mafia_quick_match(p_player_id text, p_name text)
returns table (code text, token uuid)
language plpgsql security definer set search_path = public as $$
declare r mafia_rooms; t uuid;
begin
  select * into r from mafia_rooms ro
   where ro.mode = 'random' and ro.phase = 'lobby' and ro.created_at > now() - interval '10 minutes'
     and (select count(*) from mafia_players p where p.room_code = ro.code and not p.is_ai) < 10
   order by ro.created_at limit 1 for update skip locked;
  if found then
    t := mafia_join_room(r.code, p_player_id, p_name);
    return query select r.code, t;
  end if;
  return query select * from mafia_create_room(p_player_id, p_name, 'random');
end $$;

create or replace function mafia_start(p_code text, p_player_id text, p_token uuid) returns void
language plpgsql security definer set search_path = public as $$
declare r mafia_rooms; n int; n_maf int; ids text[]; i int; roles text[];
  ai_names text[] := array['Akmal','Bekzod','Dilshod','Feruza','Gulnora','Jasur','Kamola','Lola','Nodir','Rustam','Sevara','Timur'];
begin
  perform _mafia_auth(p_code, p_player_id, p_token);
  select * into r from mafia_rooms where code = p_code for update;
  if r.host_id <> p_player_id or r.phase <> 'lobby' then raise exception 'not_allowed'; end if;
  select count(*) into n from mafia_players where room_code = p_code;
  -- AI bilan to'ldirish: kamida 6 o'yinchi (AI rejimida ham, do'stlar kam bo'lsa ham)
  while n < 6 loop
    insert into mafia_players(room_code, player_id, name, seat, is_ai)
      values (p_code, 'ai-' || n, ai_names[1 + (n % 12)], n, true);
    insert into mafia_secrets(room_code, player_id) values (p_code, 'ai-' || n);
    n := n + 1;
  end loop;
  n_maf := greatest(1, n / 3);
  roles := array_fill('civilian'::text, array[n]);
  for i in 1..n_maf loop roles[i] := 'mafia'; end loop;
  roles[n_maf + 1] := 'doctor';
  roles[n_maf + 2] := 'detective';
  select array_agg(player_id order by random()) into ids from mafia_players where room_code = p_code;
  for i in 1..n loop
    update mafia_secrets set role = roles[i] where room_code = p_code and player_id = ids[i];
  end loop;
  update mafia_rooms set phase = 'night', day = 1, phase_ends_at = now() + interval '30 seconds',
         last_event = jsonb_build_object('type', 'start') where code = p_code;
end $$;

-- ---------- o'yinchi harakatlari ----------
create or replace function mafia_act(p_code text, p_player_id text, p_token uuid, p_kind text, p_target text) returns void
language plpgsql security definer set search_path = public as $$
declare r mafia_rooms; my text;
begin
  perform _mafia_auth(p_code, p_player_id, p_token);
  select * into r from mafia_rooms where code = p_code for update;
  if r.phase not in ('night','vote') or now() > r.phase_ends_at + interval '2 seconds' then raise exception 'closed'; end if;
  if not exists (select 1 from mafia_players where room_code = p_code and player_id = p_player_id and alive) then raise exception 'dead'; end if;
  if not exists (select 1 from mafia_players where room_code = p_code and player_id = p_target and alive) then raise exception 'bad_target'; end if;
  select role into my from mafia_secrets where room_code = p_code and player_id = p_player_id;
  if r.phase = 'vote' then
    if p_kind <> 'vote' then raise exception 'wrong_kind'; end if;
  else
    if (p_kind = 'kill' and my <> 'mafia') or (p_kind = 'save' and my <> 'doctor')
       or (p_kind = 'check' and my <> 'detective') or p_kind = 'vote' then raise exception 'wrong_kind'; end if;
  end if;
  insert into mafia_actions(room_code, day, kind, actor, target) values (p_code, r.day, p_kind, p_player_id, p_target)
    on conflict (room_code, day, kind, actor) do update set target = excluded.target;
  perform mafia_advance(p_code);      -- hamma harakat qilgan bo'lsa darhol o'tadi
end $$;

-- Faqat O'Z holatingiz: rol, (mafiya bo'lsangiz) sheriklar, (detektiv bo'lsangiz) tekshiruv natijalari
create or replace function mafia_my_state(p_code text, p_player_id text, p_token uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare my text; mates jsonb := '[]'; notes jsonb;
begin
  perform _mafia_auth(p_code, p_player_id, p_token);
  select role into my from mafia_secrets where room_code = p_code and player_id = p_player_id;
  if my = 'mafia' then
    select coalesce(jsonb_agg(player_id), '[]') into mates from mafia_secrets
     where room_code = p_code and role = 'mafia' and player_id <> p_player_id;
  end if;
  select coalesce(jsonb_agg(jsonb_build_object('day', day, 'note', note)), '[]') into notes
    from mafia_notes where room_code = p_code and player_id = p_player_id;
  return jsonb_build_object('role', my, 'mates', mates, 'notes', notes);
end $$;

-- ---------- AI harakatlari va faza o'tishi ----------
create or replace function _mafia_ai_act(p_code text, p_phase text, p_day int) returns void
language plpgsql security definer set search_path = public as $$
declare a record; tgt text;
begin
  for a in
    select p.player_id, s.role from mafia_players p join mafia_secrets s using (room_code, player_id)
     where p.room_code = p_code and p.is_ai and p.alive
  loop
    if p_phase = 'night' and a.role in ('mafia','doctor','detective') then
      select p.player_id into tgt from mafia_players p join mafia_secrets s using (room_code, player_id)
       where p.room_code = p_code and p.alive and p.player_id <> a.player_id
         and (a.role <> 'mafia' or s.role <> 'mafia') order by random() limit 1;
      if a.role = 'doctor' then tgt := coalesce((select player_id from mafia_players where room_code = p_code and alive order by random() limit 1), tgt); end if;
      if tgt is not null then
        insert into mafia_actions(room_code, day, kind, actor, target)
          values (p_code, p_day, case a.role when 'mafia' then 'kill' when 'doctor' then 'save' else 'check' end, a.player_id, tgt)
          on conflict do nothing;
      end if;
    elsif p_phase = 'vote' then
      select p.player_id into tgt from mafia_players p join mafia_secrets s using (room_code, player_id)
       where p.room_code = p_code and p.alive and p.player_id <> a.player_id
         and (a.role <> 'mafia' or s.role <> 'mafia') order by random() limit 1;
      if tgt is not null then
        insert into mafia_actions(room_code, day, kind, actor, target) values (p_code, p_day, 'vote', a.player_id, tgt)
          on conflict do nothing;
      end if;
    end if;
  end loop;
end $$;

-- Har kim chaqira oladi: server o'zi muddat/harakatlarni tekshiradi, ortiqcha chaqiruv zarar qilmaydi.
create or replace function mafia_advance(p_code text) returns void
language plpgsql security definer set search_path = public as $$
declare r mafia_rooms; need int; done int; kt text; st text; vt text; killed text; w text; ev jsonb; a record;
begin
  select * into r from mafia_rooms where code = p_code for update;
  if not found or r.phase in ('lobby','gameover') then return; end if;

  if r.phase = 'night' then
    select count(*) into need from mafia_players p join mafia_secrets s using (room_code, player_id)
     where p.room_code = p_code and p.alive and not p.is_ai and s.role in ('mafia','doctor','detective');
    select count(*) into done from mafia_actions x join mafia_players p on p.room_code = x.room_code and p.player_id = x.actor
     where x.room_code = p_code and x.day = r.day and x.kind in ('kill','save','check') and not p.is_ai;
  elsif r.phase = 'vote' then
    select count(*) into need from mafia_players where room_code = p_code and alive and not is_ai;
    select count(*) into done from mafia_actions x join mafia_players p on p.room_code = x.room_code and p.player_id = x.actor
     where x.room_code = p_code and x.day = r.day and x.kind = 'vote' and not p.is_ai;
  else
    need := 1; done := 0;                       -- kunduzi muhokama: faqat vaqt bo'yicha
  end if;
  if now() < r.phase_ends_at and done < need then return; end if;

  perform _mafia_ai_act(p_code, r.phase, r.day);

  if r.phase = 'night' then
    select target into kt from mafia_actions where room_code = p_code and day = r.day and kind = 'kill'
      group by target order by count(*) desc, random() limit 1;
    select target into st from mafia_actions where room_code = p_code and day = r.day and kind = 'save' limit 1;
    for a in select actor, target from mafia_actions where room_code = p_code and day = r.day and kind = 'check' loop
      insert into mafia_notes(room_code, player_id, day, note)
        select p_code, a.actor, r.day,
               (select name from mafia_players where room_code = p_code and player_id = a.target) || ': ' ||
               case when (select role from mafia_secrets where room_code = p_code and player_id = a.target) = 'mafia' then 'MAFIA' else 'mafia emas' end;
    end loop;
    if kt is not null and kt is distinct from st then perform _mafia_kill(p_code, kt); killed := kt; end if;
    ev := jsonb_build_object('type', 'night', 'killed', killed, 'saved', (kt is not null and kt = st));
    w := _mafia_check_win(p_code);
    if w is not null then
      update mafia_rooms set phase = 'gameover', winner = w, last_event = ev, phase_ends_at = null where code = p_code;
    else
      update mafia_rooms set phase = 'day', phase_ends_at = now() + interval '45 seconds', last_event = ev where code = p_code;
    end if;

  elsif r.phase = 'day' then
    update mafia_rooms set phase = 'vote', phase_ends_at = now() + interval '30 seconds',
           last_event = jsonb_build_object('type', 'vote_open') where code = p_code;

  elsif r.phase = 'vote' then
    -- durrang bo'lsa hech kim chiqarilmaydi
    with t as (select target, count(*) c from mafia_actions where room_code = p_code and day = r.day and kind = 'vote' group by target),
         m as (select max(c) mc from t)
    select target into vt from t, m where t.c = m.mc and (select count(*) from t, m m2 where t.c = m2.mc) = 1;
    if vt is not null then perform _mafia_kill(p_code, vt); end if;
    ev := jsonb_build_object('type', 'vote', 'eliminated', vt,
      'tally', (select coalesce(jsonb_object_agg(target, c), '{}') from
                 (select target, count(*) c from mafia_actions where room_code = p_code and day = r.day and kind = 'vote' group by target) q));
    w := _mafia_check_win(p_code);
    if w is not null then
      update mafia_rooms set phase = 'gameover', winner = w, last_event = ev, phase_ends_at = null where code = p_code;
    else
      update mafia_rooms set phase = 'night', day = r.day + 1, phase_ends_at = now() + interval '30 seconds', last_event = ev where code = p_code;
    end if;
  end if;

  -- o'yin tugasa hamma rol ochiladi
  update mafia_players p set revealed_role = s.role from mafia_secrets s
   where p.room_code = p_code and s.room_code = p.room_code and s.player_id = p.player_id
     and (select phase from mafia_rooms where code = p_code) = 'gameover' and p.revealed_role is null;
end $$;

-- Funksiyalarni faqat RPC sifatida oching; yordamchilar yopiq qoladi.
revoke all on function _mafia_auth(text, text, uuid), _mafia_check_win(text), _mafia_kill(text, text), _mafia_ai_act(text, text, int) from public, anon, authenticated;
grant execute on function mafia_create_room(text, text, text), mafia_join_room(text, text, text), mafia_quick_match(text, text),
  mafia_start(text, text, uuid), mafia_act(text, text, uuid, text, text), mafia_my_state(text, text, uuid), mafia_advance(text) to anon, authenticated;
