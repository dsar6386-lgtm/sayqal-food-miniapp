-- SAYQAL FOOD · Mafia v2: Telegram initData tekshiruvi, lobbidan chiqish, serverda avto-start.
-- v1 migratsiyadan KEYIN ishga tushiring.
-- Bot tokenni bir marta kiriting (SQL Editor, faqat siz ko'rasiz):
--   insert into mafia_config(key,value) values ('bot_token','123456:ABC...') on conflict (key) do update set value=excluded.value;
-- Faqat Telegram ichida ochilganlarga ruxsat berish uchun (ixtiyoriy):
--   insert into mafia_config(key,value) values ('require_auth','1') on conflict (key) do update set value=excluded.value;

create extension if not exists pgcrypto;

create table if not exists mafia_config (key text primary key, value text not null);
alter table mafia_config enable row level security;   -- policy yo'q: anon o'qiy olmaydi

create or replace function _mafia_urldecode(t text) returns text
language sql immutable as $$
  select convert_from(coalesce(string_agg(
           case when m[1] is not null then decode(substr(m[1], 2), 'hex') else convert_to(m[2], 'UTF8') end, ''::bytea), ''::bytea), 'UTF8')
    from regexp_matches(replace(coalesce(t,''), '+', ' '), '(%[0-9a-fA-F]{2})|([^%]+|%)', 'g') as m
$$;

-- Telegram initData imzosini tekshiradi; to'g'ri bo'lsa user JSON'ini qaytaradi, aks holda null.
create or replace function _mafia_verify(p_init text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare tok text; dcs text; h text; secret bytea; ad bigint;
begin
  select value into tok from mafia_config where key = 'bot_token';
  if tok is null or p_init is null or p_init = '' then return null; end if;
  select string_agg(split_part(kv, '=', 1) || '=' || _mafia_urldecode(substr(kv, position('=' in kv) + 1)), E'\n' order by split_part(kv, '=', 1))
    into dcs from unnest(string_to_array(p_init, '&')) kv where split_part(kv, '=', 1) <> 'hash';
  select _mafia_urldecode(substr(kv, 6)) into h from unnest(string_to_array(p_init, '&')) kv where kv like 'hash=%';
  secret := hmac(convert_to(tok, 'UTF8'), convert_to('WebAppData', 'UTF8'), 'sha256');
  if h is null or encode(hmac(convert_to(dcs, 'UTF8'), secret, 'sha256'), 'hex') <> lower(h) then return null; end if;
  select _mafia_urldecode(substr(kv, 11))::bigint into ad from unnest(string_to_array(p_init, '&')) kv where kv like 'auth_date=%';
  if ad is null or extract(epoch from now()) - ad > 86400 then return null; end if;
  return (select _mafia_urldecode(substr(kv, 6))::jsonb from unnest(string_to_array(p_init, '&')) kv where kv like 'user=%');
end $$;

-- Kim ekanini aniqlaydi: tasdiqlangan Telegram foydalanuvchisi yoki mehmon.
create or replace function _mafia_identity(p_init text, p_pid text, p_name text, out pid text, out pname text)
language plpgsql security definer set search_path = public as $$
declare u jsonb; tok text; req text;
begin
  select value into tok from mafia_config where key = 'bot_token';
  select value into req from mafia_config where key = 'require_auth';
  u := _mafia_verify(p_init);
  if u is not null then
    pid := 'tg-' || (u->>'id'); pname := left(coalesce(nullif(u->>'first_name',''), p_name, 'Player'), 24); return;
  end if;
  if tok is not null and p_init is not null and p_init <> '' then raise exception 'bad_init'; end if;
  if req = '1' then raise exception 'auth_required'; end if;
  if p_pid is null or p_pid like 'ai-%' or (tok is not null and p_pid like 'tg-%') then raise exception 'bad_init'; end if;
  pid := p_pid; pname := left(coalesce(nullif(p_name,''), 'Mehmon'), 24);
end $$;

-- ---------- xona yaratish / qo'shilish (yangi imzolar) ----------
drop function if exists mafia_create_room(text, text, text);
drop function if exists mafia_join_room(text, text, text);
drop function if exists mafia_quick_match(text, text);

create or replace function _mafia_create(p_pid text, p_pname text, p_mode text)
returns table (code text, token uuid)
language plpgsql security definer set search_path = public as $$
declare c text; t uuid;
begin
  if p_mode not in ('friends','random') then raise exception 'bad_mode'; end if;
  loop
    c := upper(substr(md5(random()::text || clock_timestamp()::text), 1, 5));
    exit when not exists (select 1 from mafia_rooms where mafia_rooms.code = c);
  end loop;
  insert into mafia_rooms(code, host_id, mode) values (c, p_pid, p_mode);
  insert into mafia_players(room_code, player_id, name, seat) values (c, p_pid, p_pname, 0);
  insert into mafia_secrets(room_code, player_id) values (c, p_pid) returning mafia_secrets.token into t;
  return query select c, t;
end $$;

create or replace function mafia_create_room(p_player_id text, p_name text, p_mode text default 'friends', p_init_data text default null)
returns table (code text, token uuid)
language plpgsql security definer set search_path = public as $$
declare me record;
begin
  select * into me from _mafia_identity(p_init_data, p_player_id, p_name);
  return query select * from _mafia_create(me.pid, me.pname, p_mode);
end $$;

create or replace function _mafia_join(p_code text, p_pid text, p_pname text) returns uuid
language plpgsql security definer set search_path = public as $$
declare r mafia_rooms; t uuid; n int; sx int;
begin
  select * into r from mafia_rooms where code = upper(p_code) for update;
  if not found then raise exception 'room_unavailable'; end if;
  select token into t from mafia_secrets where room_code = r.code and player_id = p_pid;
  if t is not null then return t; end if;                         -- qayta ulanish (o'yin ketayotgan bo'lsa ham)
  if r.phase <> 'lobby' then raise exception 'room_unavailable'; end if;
  select count(*), coalesce(max(seat), -1) + 1 into n, sx from mafia_players where room_code = r.code;
  if n >= 12 then raise exception 'room_full'; end if;
  insert into mafia_players(room_code, player_id, name, seat) values (r.code, p_pid, p_pname, sx);
  insert into mafia_secrets(room_code, player_id) values (r.code, p_pid) returning token into t;
  return t;
end $$;

create or replace function mafia_join_room(p_code text, p_player_id text, p_name text, p_init_data text default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare me record;
begin
  select * into me from _mafia_identity(p_init_data, p_player_id, p_name);
  return _mafia_join(p_code, me.pid, me.pname);
end $$;

create or replace function mafia_quick_match(p_player_id text, p_name text, p_init_data text default null)
returns table (code text, token uuid)
language plpgsql security definer set search_path = public as $$
declare r mafia_rooms; t uuid; me record;
begin
  select * into me from _mafia_identity(p_init_data, p_player_id, p_name);
  -- avval allaqachon o'zim bo'lgan faol xonaga qaytaman
  select ro.* into r from mafia_rooms ro join mafia_secrets s on s.room_code = ro.code
   where s.player_id = me.pid and ro.mode = 'random' and ro.phase <> 'gameover' and ro.created_at > now() - interval '30 minutes' limit 1;
  if found then return query select r.code, (select s2.token from mafia_secrets s2 where s2.room_code = r.code and s2.player_id = me.pid); return; end if;
  select ro.* into r from mafia_rooms ro
   where ro.mode = 'random' and ro.phase = 'lobby' and ro.created_at > now() - interval '3 minutes'
     and (select count(*) from mafia_players p where p.room_code = ro.code and not p.is_ai) < 10
   order by ro.created_at limit 1 for update skip locked;
  if found then
    t := _mafia_join(r.code, me.pid, me.pname);
    return query select r.code, t; return;
  end if;
  return query select * from _mafia_create(me.pid, me.pname, 'random');
end $$;

-- ---------- lobbidan chiqish ----------
create or replace function mafia_leave(p_code text, p_player_id text, p_token uuid) returns void
language plpgsql security definer set search_path = public as $$
declare r mafia_rooms; nh text;
begin
  perform _mafia_auth(p_code, p_player_id, p_token);
  select * into r from mafia_rooms where code = p_code for update;
  if r.phase <> 'lobby' then return; end if;          -- o'yin boshlangach chiqish — AI emas, o'yinchi qoladi
  delete from mafia_secrets where room_code = p_code and player_id = p_player_id;
  delete from mafia_players where room_code = p_code and player_id = p_player_id;
  select player_id into nh from mafia_players where room_code = p_code and not is_ai order by seat limit 1;
  if nh is null then delete from mafia_rooms where code = p_code; return; end if;
  if r.host_id = p_player_id then update mafia_rooms set host_id = nh where code = p_code; end if;
  update mafia_players p set seat = x.rn - 1 from (select player_id, row_number() over (order by seat) rn from mafia_players where room_code = p_code) x
   where p.room_code = p_code and p.player_id = x.player_id;
end $$;

-- ---------- boshlash: host yoki serverdagi avto-start ----------
create or replace function _mafia_begin(p_code text) returns void
language plpgsql security definer set search_path = public as $$
declare n int; n_maf int; ids text[]; i int; roles text[];
  ai_names text[] := array['Akmal','Bekzod','Dilshod','Feruza','Gulnora','Jasur','Kamola','Lola','Nodir','Rustam','Sevara','Timur'];
begin
  select count(*) into n from mafia_players where room_code = p_code;
  while n < 6 loop
    insert into mafia_players(room_code, player_id, name, seat, is_ai)
      values (p_code, 'ai-' || n, ai_names[1 + (n % 12)], n, true);
    insert into mafia_secrets(room_code, player_id) values (p_code, 'ai-' || n);
    n := n + 1;
  end loop;
  -- seat'larni tartibli qilamiz
  update mafia_players p set seat = x.rn - 1 from (select player_id, row_number() over (order by seat) rn from mafia_players where room_code = p_code) x
   where p.room_code = p_code and p.player_id = x.player_id;
  n_maf := greatest(1, n / 3);
  roles := array_fill('civilian'::text, array[n]);
  for i in 1..n_maf loop roles[i] := 'mafia'; end loop;
  roles[n_maf + 1] := 'doctor';
  roles[n_maf + 2] := 'detective';
  select array_agg(player_id order by random()) into ids from mafia_players where room_code = p_code;
  for i in 1..n loop
    update mafia_secrets set role = roles[i] where room_code = p_code and player_id = ids[i];
  end loop;
  update mafia_rooms set phase = 'night', day = 1, phase_ends_at = now() + interval '30 seconds',
         last_event = jsonb_build_object('type', 'start') where code = p_code;
end $$;

create or replace function mafia_start(p_code text, p_player_id text, p_token uuid) returns void
language plpgsql security definer set search_path = public as $$
declare r mafia_rooms;
begin
  perform _mafia_auth(p_code, p_player_id, p_token);
  select * into r from mafia_rooms where code = p_code for update;
  if r.host_id <> p_player_id or r.phase <> 'lobby' then raise exception 'not_allowed'; end if;
  perform _mafia_begin(p_code);
end $$;

-- Tasodifiy xona: 5+ odam yoki 20 soniya o'tgach (kamida 1 odam, qolgani AI) — o'zi boshlanadi.
create or replace function mafia_lobby_tick(p_code text, p_player_id text, p_token uuid) returns void
language plpgsql security definer set search_path = public as $$
declare r mafia_rooms; humans int;
begin
  perform _mafia_auth(p_code, p_player_id, p_token);
  select * into r from mafia_rooms where code = p_code for update;
  if r.phase <> 'lobby' or r.mode <> 'random' then return; end if;
  select count(*) into humans from mafia_players where room_code = p_code and not is_ai;
  if humans >= 6 or (humans >= 2 and now() - r.created_at > interval '20 seconds') or (now() - r.created_at > interval '35 seconds') then
    perform _mafia_begin(p_code);
  end if;
end $$;

grant execute on function mafia_create_room(text,text,text,text), mafia_join_room(text,text,text,text), mafia_quick_match(text,text,text),
  mafia_leave(text,text,uuid), mafia_lobby_tick(text,text,uuid) to anon, authenticated;
revoke execute on function _mafia_verify(text), _mafia_identity(text,text,text), _mafia_join(text,text,text), _mafia_create(text,text,text), _mafia_begin(text), _mafia_urldecode(text) from public, anon, authenticated;
